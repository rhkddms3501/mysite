package com.douzone.web.mvc;

public abstract class ActionFactory {
	public abstract Action getAction(String actionName);
}
